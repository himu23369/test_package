import math

def square_area(side_length):
    return print("Area of Square:",side_length ** 2)

def rectangle_area(length, width):
    return print("Area of Rectangle:",length * width)

def circle_area(radius):
    return print("Area of Circle:",math.pi * radius ** 2)
